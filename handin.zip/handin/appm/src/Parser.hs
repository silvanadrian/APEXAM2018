module Parser (parseVersion, parseDatabase) where

-- Do not modify this file, and do not import directly from ParserImpl,
-- elsewhere, except for white-box testing.

import ParserImpl
